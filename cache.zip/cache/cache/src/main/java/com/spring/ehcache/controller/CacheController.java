package com.spring.ehcache.controller;

import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.spring.ehcache.Model.CachePojo;
import com.spring.ehcache.service.CacheService;


@RestController
public class CacheController 
{
	@Value("${my.greetings}")
	private String mygreetings;
	
	@Autowired
	private CacheService chservice; 
	
	@GetMapping("/")
	public String myGreeting() 
	{
		return mygreetings;
	}
	
	@GetMapping("/cache/{id}")
	public Optional<CachePojo> getMyCache(@PathVariable("id") String cacheid)
	{
		System.out.println(cacheid);
		return chservice.getMyCache(cacheid);
	}
	

}
