package com.spring.ehcache.service;


import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.spring.ehcache.Model.CachePojo;

@Service
public class CacheService
{
	
	/*
	 * @CacheEvict(value = "cache", key = "'mycache'+#cacheid", beforeInvocation = true)*
	 * 
	 */
	 
//	@Cacheable(value = "cache", key = "'mycache'+#cacheid")
	@CacheEvict(value = "Least-Time-Cache" , key = "'mycache'+#cacheid",condition = "#iscacheable!=null && #iscacheable==false",beforeInvocation = true)
	@Cacheable(value = "Least-Time-Cache" , key = "'mycache'+#cacheid",condition = "#iscacheable!=null && #iscacheable")
	public Optional<CachePojo> getMyCache(String cacheid,boolean iscacheable) 
	{
		try 
		{
	     Thread.sleep(5000L);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return getAllCache().stream().filter((cache) ->cache.getId().equals(cacheid)).findFirst();
	}
	
	private List<CachePojo> getAllCache() 
	{
	
		return Arrays.asList
				(
				new CachePojo("101", "fasalcahche"),
				new CachePojo("102", "riyacache"),
				new CachePojo("103", "sharveshcache"),
				new CachePojo("104", "kirubacache"),
				new CachePojo("105", "balajicache")
				);
				
		
	}

}
